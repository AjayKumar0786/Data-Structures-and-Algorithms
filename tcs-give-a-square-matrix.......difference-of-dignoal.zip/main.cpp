#include<iostream>
using namespace std;

int main(){
    
    int n,i,j;
    cin>>n;
    
    int a[n][n];
    
    for(i=0; i<n; i++){
        for(j=0; j<n; j++){
            
            cin>>a[i][j];
        }
    }
    
    int lds=0;
    int rds =0;
    i=0;
    j=0;
    
    while(i!=n and j!=n){
        lds = lds+a[i][j];
        i++;
        j++;
    }
    
    i=0;
    j=n-1;
    
    while(i!=n and j>=0)
{
    rds=rds+a[i][j];
    i++;
    j--;
    
    
}   

cout<<abs(lds-rds);
    
    
}
